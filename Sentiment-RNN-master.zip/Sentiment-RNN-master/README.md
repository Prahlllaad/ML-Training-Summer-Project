# Sentiment-RNN
Sentiment analysis using a recurrent neural network
